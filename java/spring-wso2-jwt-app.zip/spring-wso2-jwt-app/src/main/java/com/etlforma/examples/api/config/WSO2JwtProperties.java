package com.etlforma.examples.api.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "wso2.jwt")
public class WSO2JwtProperties {
    private String issuer;
    private String audience;
    private String publicKeyUrl;
    private String gatewayUrl;
    private int cacheExpiration = 300; // 5 minuti default

    // Getters e Setters
    public String getIssuer() { return issuer; }
    public void setIssuer(String issuer) { this.issuer = issuer; }

    public String getAudience() { return audience; }
    public void setAudience(String audience) { this.audience = audience; }

    public String getPublicKeyUrl() { return publicKeyUrl; }
    public void setPublicKeyUrl(String publicKeyUrl) { this.publicKeyUrl = publicKeyUrl; }

    public String getGatewayUrl() { return gatewayUrl; }
    public void setGatewayUrl(String gatewayUrl) { this.gatewayUrl = gatewayUrl; }

    public int getCacheExpiration() { return cacheExpiration; }
    public void setCacheExpiration(int cacheExpiration) { this.cacheExpiration = cacheExpiration; }
}