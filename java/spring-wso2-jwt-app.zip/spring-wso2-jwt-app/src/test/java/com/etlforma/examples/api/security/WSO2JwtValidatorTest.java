package com.etlforma.examples.api.security;

import com.etlforma.examples.api.config.WSO2JwtProperties;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import java.security.Key;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class WSO2JwtValidatorTest {

    @Mock
    private WSO2JwtProperties jwtProperties;

    @Mock
    private WebClient.Builder webClientBuilder;

    @InjectMocks
    private WSO2JwtValidator jwtValidator;

    private Key testKey;
    private String validToken;

    @BeforeEach
    void setUp() {
        testKey = Keys.secretKeyFor(SignatureAlgorithm.HS256);

        when(jwtProperties.getIssuer()).thenReturn("test-issuer");
        when(jwtProperties.getAudience()).thenReturn("test-audience");

        validToken = Jwts.builder()
                .setSubject("testuser")
                .setIssuer("test-issuer")
                .setAudience("test-audience")
                .setExpiration(new Date(System.currentTimeMillis() + 3600000))
                .claim("scope", "read write")
                .signWith(testKey)
                .compact();
    }

    @Test
    void extractUsername_ShouldReturnCorrectUsername() {
        // Questo test dovrebbe essere adattato per usare mock delle chiavi pubbliche
        // Per ora è un esempio della struttura
        assertNotNull(validToken);
    }
}