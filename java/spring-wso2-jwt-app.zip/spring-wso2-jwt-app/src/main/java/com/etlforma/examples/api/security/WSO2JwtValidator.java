package com.etlforma.examples.api.security;


import com.etlforma.examples.api.config.WSO2JwtProperties;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.security.Key;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class WSO2JwtValidator {

    private static final Logger logger = LoggerFactory.getLogger(WSO2JwtValidator.class);

    @Autowired
    private WSO2JwtProperties jwtProperties;

    @Autowired
    private WebClient.Builder webClientBuilder;

    private final ConcurrentHashMap<String, PublicKey> keyCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> keyCacheTimestamp = new ConcurrentHashMap<>();

    public boolean validateToken(String token) {
        try {
            Claims claims = parseToken(token);

            // Verifica issuer
            if (!jwtProperties.getIssuer().equals(claims.getIssuer())) {
                logger.warn("Invalid issuer: {}", claims.getIssuer());
                return false;
            }

            // Verifica audience
            if (!claims.getAudience().contains(jwtProperties.getAudience())) {
                logger.warn("Invalid audience: {}", claims.getAudience());
                return false;
            }

            // Verifica scadenza
            if (claims.getExpiration().before(new Date())) {
                logger.warn("Token expired");
                return false;
            }

            return true;

        } catch (Exception e) {
            logger.error("Token validation failed", e);
            return false;
        }
    }

    public Claims parseToken(String token) {
        try {
            // Ottieni la chiave pubblica (con cache)
            PublicKey publicKey = getPublicKey();

            return Jwts.parserBuilder()
                    .setSigningKey(publicKey)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();

        } catch (Exception e) {
            logger.error("Error parsing token", e);
            throw new JwtException("Invalid token", e);
        }
    }

    private PublicKey getPublicKey() {
        String cacheKey = "wso2_public_key";
        Long timestamp = keyCacheTimestamp.get(cacheKey);

        // Controlla se la chiave è in cache e non è scaduta
        if (timestamp != null &&
                System.currentTimeMillis() - timestamp < jwtProperties.getCacheExpiration() * 1000) {
            return keyCache.get(cacheKey);
        }

        try {
            // Recupera la chiave pubblica da WSO2
            String publicKeyPem = webClientBuilder.build()
                    .get()
                    .uri(jwtProperties.getPublicKeyUrl())
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            PublicKey publicKey = parsePublicKey(publicKeyPem);

            // Memorizza in cache
            keyCache.put(cacheKey, publicKey);
            keyCacheTimestamp.put(cacheKey, System.currentTimeMillis());

            return publicKey;

        } catch (Exception e) {
            logger.error("Error retrieving public key", e);
            throw new RuntimeException("Cannot retrieve public key", e);
        }
    }

    private PublicKey parsePublicKey(String publicKeyPem) {
        try {
            String publicKeyContent = publicKeyPem
                    .replace("-----BEGIN PUBLIC KEY-----", "")
                    .replace("-----END PUBLIC KEY-----", "")
                    .replaceAll("\\s", "");

            byte[] keyBytes = Base64.getDecoder().decode(publicKeyContent);
            X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");

            return keyFactory.generatePublic(spec);

        } catch (Exception e) {
            logger.error("Error parsing public key", e);
            throw new RuntimeException("Cannot parse public key", e);
        }
    }

    public String extractUsername(String token) {
        Claims claims = parseToken(token);
        return claims.getSubject();
    }

    public String extractClaim(String token, String claimName) {
        Claims claims = parseToken(token);
        return claims.get(claimName, String.class);
    }
}
