package com.etlforma.examples.api.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/public")
@Tag(name = "Public", description = "API pubbliche senza autenticazione")
public class PublicController {

    @GetMapping("/health")
    @Operation(summary = "Health check", description = "Verifica lo stato dell'applicazione")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("timestamp", LocalDateTime.now());
        response.put("service", "Spring WSO2 JWT Application");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/info")
    @Operation(summary = "Informazioni applicazione", description = "Restituisce informazioni sull'applicazione")
    public ResponseEntity<Map<String, Object>> info() {
        Map<String, Object> response = new HashMap<>();
        response.put("name", "Spring WSO2 JWT Application");
        response.put("version", "1.0.0");
        response.put("description", "RESTful API con Spring MVC, Swagger e integrazione WSO2");
        response.put("timestamp", LocalDateTime.now());
        return ResponseEntity.ok(response);
    }

}
