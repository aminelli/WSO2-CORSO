package com.etlforma.examples.api.controller;

import com.etlforma.examples.api.model.User;
import com.etlforma.examples.api.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@Tag(name = "Users", description = "API per la gestione degli utenti")
@SecurityRequirement(name = "bearerAuth")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping
    @Operation(summary = "Ottieni tutti gli utenti", description = "Restituisce la lista di tutti gli utenti")
    @PreAuthorize("hasAuthority('SCOPE_read')")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    @GetMapping("/active")
    @Operation(summary = "Ottieni utenti attivi", description = "Restituisce solo gli utenti attivi")
    @PreAuthorize("hasAuthority('SCOPE_read')")
    public ResponseEntity<List<User>> getActiveUsers() {
        List<User> users = userService.getActiveUsers();
        return ResponseEntity.ok(users);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Ottieni utente per ID", description = "Restituisce un utente specifico tramite ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Utente trovato"),
            @ApiResponse(responseCode = "404", description = "Utente non trovato")
    })
    @PreAuthorize("hasAuthority('SCOPE_read')")
    public ResponseEntity<User> getUserById(
            @Parameter(description = "ID dell'utente") @PathVariable Long id) {
        Optional<User> user = userService.getUserById(id);
        return user.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Crea nuovo utente", description = "Crea un nuovo utente nel sistema")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Utente creato con successo"),
            @ApiResponse(responseCode = "400", description = "Dati non validi")
    })
    @PreAuthorize("hasAuthority('SCOPE_write')")
    public ResponseEntity<User> createUser(@Valid @RequestBody User user) {
        try {
            User createdUser = userService.createUser(user);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdUser);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/{id}")
    @Operation(summary = "Aggiorna utente", description = "Aggiorna i dati di un utente esistente")
    @PreAuthorize("hasAuthority('SCOPE_write')")
    public ResponseEntity<User> updateUser(
            @Parameter(description = "ID dell'utente") @PathVariable Long id,
            @Valid @RequestBody User userDetails) {
        try {
            User updatedUser = userService.updateUser(id, userDetails);
            return ResponseEntity.ok(updatedUser);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Elimina utente", description = "Elimina un utente dal sistema")
    @PreAuthorize("hasAuthority('SCOPE_delete')")
    public ResponseEntity<Void> deleteUser(
            @Parameter(description = "ID dell'utente") @PathVariable Long id) {
        try {
            userService.deleteUser(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/search")
    @Operation(summary = "Cerca utenti per nome", description = "Cerca utenti che contengono il nome specificato")
    @PreAuthorize("hasAuthority('SCOPE_read')")
    public ResponseEntity<List<User>> searchUsers(
            @Parameter(description = "Nome da cercare") @RequestParam String name) {
        List<User> users = userService.searchUsersByName(name);
        return ResponseEntity.ok(users);
    }
}
