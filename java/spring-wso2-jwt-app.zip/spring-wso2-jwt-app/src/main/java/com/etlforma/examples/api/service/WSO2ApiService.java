package com.etlforma.examples.api.service;

import com.etlforma.examples.api.config.WSO2JwtProperties;
import com.etlforma.examples.api.dto.WSO2TokenInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.time.Duration;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class WSO2ApiService {

    private static final Logger logger = LoggerFactory.getLogger(WSO2ApiService.class);

    @Autowired
    private WSO2JwtProperties jwtProperties;

    @Autowired
    private WebClient.Builder webClientBuilder;

    private final ConcurrentHashMap<String, WSO2TokenInfo> tokenCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> tokenCacheTimestamp = new ConcurrentHashMap<>();

    /**
     * Introspeziona un token tramite WSO2 API Manager
     */
    public WSO2TokenInfo introspectToken(String token) {
        // Controlla cache
        WSO2TokenInfo cachedInfo = getCachedTokenInfo(token);
        if (cachedInfo != null) {
            return cachedInfo;
        }

        try {
            MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
            formData.add("token", token);
            formData.add("token_type_hint", "access_token");

            WSO2TokenInfo tokenInfo = webClientBuilder.build()
                    .post()
                    .uri(jwtProperties.getGatewayUrl() + "/oauth2/introspect")
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                    .body(BodyInserters.fromFormData(formData))
                    .retrieve()
                    .bodyToMono(WSO2TokenInfo.class)
                    .timeout(Duration.ofSeconds(10))
                    .block();

            // Memorizza in cache se il token è attivo
            if (tokenInfo != null && tokenInfo.isActive()) {
                cacheTokenInfo(token, tokenInfo);
            }

            return tokenInfo;

        } catch (WebClientResponseException e) {
            logger.error("Error during token introspection: {} - {}", e.getStatusCode(), e.getResponseBodyAsString());
            throw new RuntimeException("Token introspection failed", e);
        } catch (Exception e) {
            logger.error("Unexpected error during token introspection", e);
            throw new RuntimeException("Token introspection failed", e);
        }
    }

    private WSO2TokenInfo getCachedTokenInfo(String token) {
        String cacheKey = generateCacheKey(token);
        Long timestamp = tokenCacheTimestamp.get(cacheKey);

        if (timestamp != null &&
                System.currentTimeMillis() - timestamp < jwtProperties.getCacheExpiration() * 1000L) {
            WSO2TokenInfo tokenInfo = tokenCache.get(cacheKey);
            if (tokenInfo != null && tokenInfo.isActive()) {
                return tokenInfo;
            }
        }

        return null;
    }

    private void cacheTokenInfo(String token, WSO2TokenInfo tokenInfo) {
        String cacheKey = generateCacheKey(token);
        tokenCache.put(cacheKey, tokenInfo);
        tokenCacheTimestamp.put(cacheKey, System.currentTimeMillis());
    }

    private String generateCacheKey(String token) {
        return "token_" + token.hashCode();
    }

    /**
     * Invalida la cache per un token specifico
     */
    public void invalidateTokenCache(String token) {
        String cacheKey = generateCacheKey(token);
        tokenCache.remove(cacheKey);
        tokenCacheTimestamp.remove(cacheKey);
    }

    /**
     * Pulisce la cache dai token scaduti
     */
    public void cleanupExpiredTokens() {
        long currentTime = System.currentTimeMillis();
        long expirationTime = jwtProperties.getCacheExpiration() * 1000L;

        tokenCacheTimestamp.entrySet().removeIf(entry -> {
            boolean expired = currentTime - entry.getValue() > expirationTime;
            if (expired) {
                tokenCache.remove(entry.getKey());
            }
            return expired;
        });

        logger.debug("Cleaned up expired tokens from cache");
    }
}
